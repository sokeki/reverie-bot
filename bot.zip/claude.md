# Reverie

Discord bot for the Hypnagogia server.

## Conventions
- No em dashes anywhere - use hyphens instead
- Separator in embeds and footers: ` • `
- Footer order: context first, then Reverie, then guild name
- Single space after emoji in field names

## Stack
- Python, discord.py, MongoDB (Motor), FastAPI dashboard
- Deployed on Heroku via GitHub