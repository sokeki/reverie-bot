"""
One-time script: clears last_match_id for accounts that had a missed post.
Run once:
    python scripts/reset_last_match.py
"""

import asyncio
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")

AFFECTED = ["Gurthru", "MacTheGenius", "nightly", "yamihere", "sokeki"]


async def reset():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    col = db["riot_accounts"]

    for name in AFFECTED:
        result = await col.update_one(
            {"val_name": name},
            {"$set": {"last_match_id": "1a4afa0a-1dca-4a6a-b93f-6bd25f3ca668"}},
        )
        if result.modified_count:
            print(f"  Reset: {name}")
        else:
            print(f"  Not found: {name}")

    print("\nDone! These accounts will detect their next game fresh.")
    client.close()


if __name__ == "__main__":
    asyncio.run(reset())
