"""
Script: verifies rr_change in val_games against Henrik MMR history
and corrects any wrong values.

Run once:
    python scripts/fix_rr_values.py
"""

import asyncio
import os
from urllib.parse import quote
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
import aiohttp

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")
HENRIK_API_KEY = os.getenv("HENRIK_API_KEY", "")
API_BASE = "https://api.henrikdev.xyz"


async def fetch_mmr_history(
    session: aiohttp.ClientSession, name: str, tag: str, region: str
) -> list:
    url = f"{API_BASE}/valorant/v1/mmr-history/{region}/{quote(name)}/{quote(tag)}"
    for attempt in range(5):
        try:
            async with session.get(
                url, headers={"Authorization": HENRIK_API_KEY}
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("data", [])
                elif resp.status == 429:
                    wait = 10 * (attempt + 1)
                    print(
                        f"  Rate limited for {name}#{tag} - waiting {wait}s (attempt {attempt + 1}/5)"
                    )
                    await asyncio.sleep(wait)
                    continue
                else:
                    print(f"  MMR history {resp.status} for {name}#{tag}")
                    return []
        except Exception as e:
            print(f"  Error fetching history for {name}#{tag}: {e}")
            return []
    print(f"  Giving up on {name}#{tag} after 5 attempts")
    return []


async def fix():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    col = db["val_games"]

    games = await col.find({}).to_list(length=10000)
    print(f"Found {len(games)} entries in val_games\n")

    # Group by player to minimise API calls
    by_player: dict[str, list] = {}
    for g in games:
        key = f"{g.get('val_name')}#{g.get('val_tag')}|{g.get('val_region', 'eu') or 'eu'}"
        by_player.setdefault(key, []).append(g)

    fixed = skipped = errors = 0

    async with aiohttp.ClientSession() as session:
        for player_key, player_games in by_player.items():
            name_tag, region = player_key.rsplit("|", 1)
            name, tag = name_tag.split("#", 1)

            history = await fetch_mmr_history(session, name, tag, region)
            if not history:
                print(
                    f"  No history for {name_tag} - skipping {len(player_games)} game(s)"
                )
                skipped += len(player_games)
                await asyncio.sleep(1)
                continue

            # Build match_id -> rr_change lookup from history
            rr_map = {
                e.get("match_id"): e.get("mmr_change_to_last_game", 0)
                for e in history
                if e.get("match_id")
            }

            for game in player_games:
                match_id = game.get("match_id")
                if not match_id or match_id not in rr_map:
                    skipped += 1
                    continue

                correct_rr = rr_map[match_id]
                stored_rr = game.get("rr_change", 0)

                if correct_rr != stored_rr:
                    await col.update_one(
                        {"_id": game["_id"]}, {"$set": {"rr_change": correct_rr}}
                    )
                    print(
                        f"  Fixed {name}#{tag} match {match_id[:8]}...: {stored_rr} -> {correct_rr}"
                    )
                    fixed += 1
                else:
                    skipped += 1

            await asyncio.sleep(1)

    print(f"\nDone! Fixed: {fixed}, Skipped/OK: {skipped}, Errors: {errors}")
    client.close()


if __name__ == "__main__":
    asyncio.run(fix())
