"""
One-time script: backfills the puuids array on existing val_match_cache
documents that don't have it yet. No API calls needed - reads from stored data.

Run once:
    python scripts/backfill_cache_puuids.py
"""

import asyncio
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")


async def backfill():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    col = db["val_match_cache"]

    # Find docs missing the puuids array
    docs = await col.find({"puuids": {"$exists": False}}).to_list(length=10000)
    print(f"Found {len(docs)} docs missing puuids array\n")

    updated = skipped = 0

    for doc in docs:
        data = doc.get("data", {})
        raw_p = data.get("players", [])
        all_p = raw_p if isinstance(raw_p, list) else raw_p.get("all_players", [])
        puuids = [
            p.get("puuid") for p in all_p if isinstance(p, dict) and p.get("puuid")
        ]

        if not puuids:
            print(f"  No players found in {doc.get('match_id', '?')[:8]}... - skipping")
            skipped += 1
            continue

        await col.update_one({"_id": doc["_id"]}, {"$set": {"puuids": puuids}})
        print(f"  Updated {doc.get('match_id', '?')[:8]}... - {len(puuids)} players")
        updated += 1

    print(f"\nDone! Updated: {updated}, Skipped: {skipped}")
    client.close()


if __name__ == "__main__":
    asyncio.run(backfill())
