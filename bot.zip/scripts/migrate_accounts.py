"""
Migration script: adds tft baseline LP to existing riot_accounts documents.

Run once:
    python scripts/migrate_accounts.py
"""

import asyncio
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
import aiohttp

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")
RIOT_API_KEY = os.getenv("RIOT_API_KEY", "")

TIER_ORDER = {
    "IRON": 0,
    "BRONZE": 400,
    "SILVER": 800,
    "GOLD": 1200,
    "PLATINUM": 1600,
    "EMERALD": 2000,
    "DIAMOND": 2400,
    "MASTER": 2800,
    "GRANDMASTER": 3200,
    "CHALLENGER": 3600,
}
DIV_ORDER = {"IV": 0, "III": 100, "II": 200, "I": 300}

VAL_TO_TFT = {
    "eu": "euw1",
    "na": "na1",
    "ap": "sg2",
    "kr": "kr",
    "br": "br1",
    "latam": "la1",
}


async def fetch_riot_puuid(
    session: aiohttp.ClientSession, name: str, tag: str
) -> str | None:
    """Fetch the real Riot PUUID using name and tag."""
    url = f"https://europe.api.riotgames.com/riot/account/v1/accounts/by-riot-id/{name}/{tag}"
    try:
        async with session.get(url, headers={"X-Riot-Token": RIOT_API_KEY}) as resp:
            if resp.status == 200:
                data = await resp.json()
                return data.get("puuid")
            text = await resp.text()
            print(f"    Account API returned {resp.status}: {text[:200]}")
    except Exception as ex:
        print(f"    Error fetching PUUID: {ex}")
    return None


async def fetch_tft_lp(session: aiohttp.ClientSession, tft_region: str, puuid: str):
    url = f"https://{tft_region}.api.riotgames.com/tft/league/v1/by-puuid/{puuid}"
    try:
        async with session.get(url, headers={"X-Riot-Token": RIOT_API_KEY}) as resp:
            if resp.status != 200:
                text = await resp.text()
                print(f"    TFT API returned {resp.status}: {text[:200]}")
                return None
            entries = await resp.json()
            for e in entries:
                if e.get("queueType") == "RANKED_TFT":
                    return (
                        TIER_ORDER.get(e["tier"].upper(), 0)
                        + DIV_ORDER.get(e["rank"].upper(), 0)
                        + e["leaguePoints"]
                    )
    except Exception as ex:
        print(f"    Error: {ex}")
    return None


async def migrate():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    col = db["riot_accounts"]

    accounts = await col.find({}).to_list(length=1000)
    print(f"Found {len(accounts)} accounts in riot_accounts\n")

    updated = skipped = 0

    async with aiohttp.ClientSession() as session:
        for acc in accounts:
            puuid = acc.get("puuid")
            val_name = acc.get("val_name", "?")
            val_tag = acc.get("val_tag", "?")
            val_region = acc.get("val_region", "eu")
            tft = acc.get("tft", {})

            # Skip if already has a real LP value
            if tft and tft.get("lp") is not None:
                print(
                    f"  Already has TFT LP: {val_name}#{val_tag} ({tft['lp']}) - skipping"
                )
                skipped += 1
                continue

            tft_region = VAL_TO_TFT.get(val_region, "euw1")
            print(f"  Fetching real PUUID for {val_name}#{val_tag}...")
            real_puuid = await fetch_riot_puuid(session, val_name, val_tag)
            if not real_puuid:
                print(f"    Could not fetch real PUUID, skipping TFT LP")
                skipped += 1
                continue
            # Update the stored PUUID to the real one
            await col.update_one(
                {"_id": acc["_id"]}, {"$set": {"riot_puuid": real_puuid}}
            )
            print(f"  Fetching TFT LP for {val_name}#{val_tag} ({tft_region})...")
            tft_lp = await fetch_tft_lp(session, tft_region, real_puuid)

            await col.update_one(
                {"_id": acc["_id"]},
                {
                    "$set": {
                        "tft.lp": tft_lp,
                        "tft.region": tft_region,
                        "tft.last_match_ids": tft.get("last_match_ids", []),
                    }
                },
            )
            print(f"  Updated: {val_name}#{val_tag} - TFT LP: {tft_lp}")
            updated += 1
            await asyncio.sleep(1)

    print(f"\nDone! Updated: {updated}, Skipped: {skipped}")
    client.close()


if __name__ == "__main__":
    asyncio.run(migrate())
