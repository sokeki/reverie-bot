"""
Script: updates the stored old nickname for a user in comp_nick_winners
so it resets correctly next recap.

Run once:
    python scripts/fix_comp_nick.py
"""

import asyncio
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")
GUILD_ID = int(os.getenv("GUILD_ID", "0"))
USER_ID = "731094068632879135"
OLD_NICK = "mika"


async def main():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]

    result = await db["guild_settings"].update_one(
        {"guild_id": GUILD_ID},
        {"$set": {f"comp_nick_winners.{USER_ID}": OLD_NICK}},
    )
    if result.modified_count == 0:
        # Try the settings collection
        result = await db["settings"].update_one(
            {"guild_id": GUILD_ID},
            {"$set": {f"comp_nick_winners.{USER_ID}": OLD_NICK}},
        )

    print(f"Updated: {result.modified_count} document(s)")
    client.close()


if __name__ == "__main__":
    asyncio.run(main())
