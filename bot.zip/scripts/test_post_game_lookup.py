"""
Test script: simulates the history lookup in _post_new_game for a match-scan account.
Checks if the match ID comparison works correctly.

Run with:
    python scripts/test_post_game_lookup.py
"""

import asyncio
import os
from urllib.parse import quote
from dotenv import load_dotenv
import aiohttp

load_dotenv()

HENRIK_API_KEY = os.getenv("HENRIK_API_KEY", "")
API_BASE = "https://api.henrikdev.xyz"

# Simulate a match-scan account
NAME = "sokeki"
TAG = "6666"
REGION = "eu"
MATCH_ID = "01ea3f3d-5c3c-4957-9524-03c622430fb3"


async def main():
    async with aiohttp.ClientSession() as session:
        url = f"{API_BASE}/valorant/v1/mmr-history/{REGION}/{quote(NAME)}/{quote(TAG)}"
        async with session.get(url, headers={"Authorization": HENRIK_API_KEY}) as resp:
            data = await resp.json()
            history = data.get("data", [])

        print(f"History count: {len(history)}")
        print(f"Looking for:   '{MATCH_ID}'")
        print(
            f"History[0] id: '{history[0].get('match_id', '?') if history else 'none'}'"
        )
        print(f"Match: {MATCH_ID == history[0].get('match_id') if history else False}")
        print()

        entry = next((e for e in history if e.get("match_id") == MATCH_ID), None)
        if entry:
            print(f"FOUND: rr_change={entry['mmr_change_to_last_game']:+d}")
        else:
            print("NOT FOUND - IDs differ or match not in history")
            print("All history match IDs:")
            for e in history:
                print(f"  '{e.get('match_id', '?')}'")


if __name__ == "__main__":
    asyncio.run(main())
