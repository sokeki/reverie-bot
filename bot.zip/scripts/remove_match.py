"""
One-time script: removes a specific match from all collections.
Run once:
    python scripts/remove_match.py
"""

import asyncio
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")
OLD_MATCH = "1a4afa0a-1dca-4a6a-b93f-6bd25f3ca668"
NEW_MATCH = "52f2a418-2888-405d-ae61-0b51ade5c17c"


async def remove():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]

    # Remove from val_games
    r1 = await db["val_games"].delete_many({"match_id": OLD_MATCH})
    print(f"val_games:       removed {r1.deleted_count}")

    # Remove from val_match_cache
    r2 = await db["val_match_cache"].delete_many({"match_id": OLD_MATCH})
    print(f"val_match_cache: removed {r2.deleted_count}")

    # Set last_match_id to this match so next game gets detected normally
    r3 = await db["riot_accounts"].update_many(
        {"last_match_id": OLD_MATCH},
        {"$set": {"last_match_id": NEW_MATCH, "last_game_start": 0}},
    )
    print(f"riot_accounts:   set {r3.modified_count} account(s) to baseline match")

    print("\nDone!")
    client.close()


if __name__ == "__main__":
    asyncio.run(remove())
