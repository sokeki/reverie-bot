"""
One-time script: removes duplicate val_games entries where the same player
has multiple entries on the same date with identical kills/deaths/assists/agent/map.
Keeps the entry with the most plausible rr_change (prefers the one matching won/loss).

Run once:
    python scripts/dedup_val_games_content.py
"""

import asyncio
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")


def _content_key(doc: dict) -> tuple:
    """Fingerprint a game by player + date + stats."""
    return (
        doc.get("puuid") or doc.get("discord_id", ""),
        doc.get("date", ""),
        doc.get("kills", 0),
        doc.get("deaths", 0),
        doc.get("assists", 0),
        doc.get("agent", ""),
        doc.get("map", ""),
    )


def _best_doc(docs: list) -> dict:
    """Pick the best entry from a group of duplicates.
    Prefer entries where rr_change sign matches won (positive win, negative loss).
    """
    for doc in docs:
        won = doc.get("won", False)
        rr_change = doc.get("rr_change", 0)
        if won and rr_change > 0:
            return doc
        if not won and rr_change < 0:
            return doc
    # If none match, just keep the first
    return docs[0]


async def dedup():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    col = db["val_games"]

    all_games = await col.find({}).to_list(length=10000)
    print(f"Found {len(all_games)} total entries in val_games\n")

    # Group by content fingerprint
    groups: dict[tuple, list] = {}
    for doc in all_games:
        key = _content_key(doc)
        groups.setdefault(key, []).append(doc)

    to_delete = []
    for key, docs in groups.items():
        if len(docs) == 1:
            continue
        best = _best_doc(docs)
        for doc in docs:
            if doc["_id"] != best["_id"]:
                to_delete.append(doc["_id"])
                print(
                    f"  Removing duplicate: {doc.get('val_name')}#{doc.get('val_tag')} "
                    f"{doc.get('date')} {doc.get('agent')} on {doc.get('map')} "
                    f"match={doc.get('match_id', '?')[:8]}... rr={doc.get('rr_change')}"
                )
        print(
            f"  Keeping:  {best.get('val_name')}#{best.get('val_tag')} "
            f"match={best.get('match_id', '?')[:8]}... rr={best.get('rr_change')}"
        )

    if to_delete:
        result = await col.delete_many({"_id": {"$in": to_delete}})
        print(f"\nRemoved {result.deleted_count} duplicate(s)")
    else:
        print("No content duplicates found!")

    print(f"Remaining entries: {await col.count_documents({})}")
    print("\nDone!")
    client.close()


if __name__ == "__main__":
    asyncio.run(dedup())
