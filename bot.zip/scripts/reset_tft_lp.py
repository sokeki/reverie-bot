"""
Script: resets tft.lp to null for all riot_accounts so they re-baseline
correctly on next poll.

Run once:
    python scripts/reset_tft_lp.py
"""

import asyncio
import os
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")
GUILD_ID = int(os.getenv("GUILD_ID", "0"))


async def main():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]

    result = await db["riot_accounts"].update_many(
        {"guild_id": GUILD_ID}, {"$set": {"tft.lp": None, "tft.baselined": False}}
    )
    print(f"Reset tft.lp to null for {result.modified_count} account(s)")
    client.close()


if __name__ == "__main__":
    asyncio.run(main())
