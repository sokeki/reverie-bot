"""
Script: inserts comp roll data for the current week to test nickname awards.
Based on data from week 2026-04-12.

Run once:
    python scripts/insert_test_comp_rolls.py
"""

import asyncio
import os
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")
GUILD_ID = int(os.getenv("GUILD_ID", "0"))


async def main():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]

    # Current week's Sunday key
    now = datetime.now(timezone.utc)
    week = (now - timedelta(days=(now.weekday() + 1) % 7)).strftime("%Y-%m-%d")
    print(f"Inserting for week: {week}")

    rolls = [
        {"role": "Free Pick", "user_id": 527828678462406656, "count": 6},
        {"role": "Sentinel", "user_id": 527828678462406656, "count": 6},
        {"role": "Controller", "user_id": 318442060187172866, "count": 7},
        {"role": "Initiator", "user_id": 731094068632879135, "count": 4},
        {"role": "Duelist", "user_id": 524975072583221258, "count": 8},
    ]

    for r in rolls:
        await db["comp_rolls"].update_one(
            {
                "guild_id": GUILD_ID,
                "user_id": r["user_id"],
                "week": week,
                "role": r["role"],
            },
            {"$set": {"count": r["count"]}},
            upsert=True,
        )
        print(f"  Inserted {r['role']}: user {r['user_id']} ({r['count']}x)")

    print("\nDone! Now run /sendrecap to test nicknames.")
    client.close()


if __name__ == "__main__":
    asyncio.run(main())
