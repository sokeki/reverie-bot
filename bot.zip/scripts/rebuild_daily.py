"""
Script: clears val_games for 2026-04-15, repulls last 10 matches from Henrik
for all tracked accounts, rebuilds the entries, then posts the daily summary
to the configured RR channel.

Run once:
    python scripts/rebuild_daily.py
"""

import asyncio
import os
from datetime import datetime, timezone
from urllib.parse import quote

import aiohttp
import discord
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")
HENRIK_API_KEY = os.getenv("HENRIK_API_KEY", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
GUILD_ID = int(os.getenv("GUILD_ID", "0"))
API_BASE = "https://api.henrikdev.xyz"
TARGET_DATE = "2026-04-15"
COLOUR_LB = 0x7B68EE


async def fetch_live_mmr(session, name, tag, region):
    url = f"{API_BASE}/valorant/v3/mmr/{region}/pc/{quote(name)}/{quote(tag)}"
    for attempt in range(4):
        try:
            async with session.get(
                url, headers={"Authorization": HENRIK_API_KEY}
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("data", {})
                elif resp.status == 429:
                    wait = 10 * (attempt + 1)
                    print(f"  Rate limited - waiting {wait}s")
                    await asyncio.sleep(wait)
                else:
                    return {}
        except Exception as e:
            print(f"  Error: {e}")
            return {}
    return {}


async def fetch_matches(session, name, tag, region, count=10):
    url = f"{API_BASE}/valorant/v3/matches/{region}/{quote(name)}/{quote(tag)}?mode=competitive&size={count}"
    for attempt in range(4):
        try:
            async with session.get(
                url, headers={"Authorization": HENRIK_API_KEY}
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("data", [])
                elif resp.status == 429:
                    wait = 10 * (attempt + 1)
                    print(f"  Rate limited - waiting {wait}s")
                    await asyncio.sleep(wait)
                else:
                    print(f"  Matches {resp.status} for {name}#{tag}")
                    return []
        except Exception as e:
            print(f"  Error: {e}")
            return []
    return []


async def fetch_mmr_history(session, name, tag, region):
    url = f"{API_BASE}/valorant/v1/mmr-history/{region}/{quote(name)}/{quote(tag)}"
    for attempt in range(4):
        try:
            async with session.get(
                url, headers={"Authorization": HENRIK_API_KEY}
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data.get("data", [])
                elif resp.status == 429:
                    wait = 10 * (attempt + 1)
                    print(f"  Rate limited - waiting {wait}s")
                    await asyncio.sleep(wait)
                else:
                    print(f"  MMR history {resp.status} for {name}#{tag}")
                    return []
        except Exception as e:
            print(f"  Error: {e}")
            return []
    return []


def _winning_team(match: dict) -> str:
    teams = match.get("teams", {})
    if isinstance(teams, list):
        for team in teams:
            if isinstance(team, dict) and team.get("won"):
                return team.get("team_id", "").lower()
    elif isinstance(teams, dict):
        for team_name, team_data in teams.items():
            if isinstance(team_data, dict) and team_data.get("has_won"):
                return team_name.lower()
    return ""


async def rebuild():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]

    # 1. Delete all val_games for target date
    r = await db["val_games"].delete_many({"date": TARGET_DATE})
    print(f"Deleted {r.deleted_count} val_games entries for {TARGET_DATE}\n")

    # 2. Get all tracked accounts
    accounts = (
        await db["riot_accounts"].find({"guild_id": GUILD_ID}).to_list(length=100)
    )
    print(f"Found {len(accounts)} tracked accounts\n")

    inserted_total = 0

    async with aiohttp.ClientSession() as session:
        for account in accounts:
            name = account["val_name"]
            tag = account["val_tag"]
            region = account.get("val_region", "eu")
            puuid = account.get("puuid", "")

            print(f"Processing {name}#{tag}...")

            # Fetch matches and MMR history
            matches = await fetch_matches(session, name, tag, region)
            history = await fetch_mmr_history(session, name, tag, region)
            rr_map = {
                e.get("match_id"): e.get("mmr_change_to_last_game", 0)
                for e in history
                if e.get("match_id")
            }

            inserted = 0
            for match in matches:
                metadata = match.get("metadata", {})
                match_id = metadata.get("matchid") or metadata.get("match_id", "")
                game_start = metadata.get("game_start", 0)

                # Convert epoch to date string
                if game_start:
                    game_date = datetime.fromtimestamp(
                        game_start, tz=timezone.utc
                    ).strftime("%Y-%m-%d")
                else:
                    game_date = TARGET_DATE

                if game_date != TARGET_DATE:
                    continue

                raw_map = metadata.get("map", "Unknown")
                map_name = (
                    raw_map
                    if isinstance(raw_map, str)
                    else raw_map.get("name", "Unknown")
                )

                # Find player in match
                raw_p = match.get("players", [])
                all_p = (
                    raw_p if isinstance(raw_p, list) else raw_p.get("all_players", [])
                )
                player = next(
                    (
                        p
                        for p in all_p
                        if isinstance(p, dict) and p.get("puuid") == puuid
                    ),
                    None,
                )
                if not player:
                    continue

                stats = player.get("stats", {})
                kills = stats.get("kills", 0)
                deaths = stats.get("deaths", 0)
                assists = stats.get("assists", 0)
                agent = player.get("agent", {}).get("name") or player.get(
                    "character", "Unknown"
                )
                team = (player.get("team_id") or player.get("team", "")).lower()
                winning_team = _winning_team(match)
                won = bool(team and team == winning_team)

                # Get rr_change, rr_after and tier from history entry
                rr_entry = next(
                    (e for e in history if e.get("match_id") == match_id), None
                )
                rr_change = (
                    rr_entry.get("mmr_change_to_last_game", 0) if rr_entry else 0
                )
                rr_after = rr_entry.get("ranking_in_tier", 0) if rr_entry else 0
                tier = rr_entry.get("currenttier_patched", "") if rr_entry else ""
                # Fallback tier and rr from player object in match
                if not tier:
                    tier = player.get("currenttier_patched", "Unknown")
                if not rr_after:
                    rr_after = player.get("ranking_in_tier", 0)

                # Skip if already exists
                exists = await db["val_games"].find_one(
                    {"puuid": puuid, "match_id": match_id}
                )
                if exists:
                    continue

                await db["val_games"].insert_one(
                    {
                        "guild_id": GUILD_ID,
                        "puuid": puuid,
                        "val_name": name,
                        "val_tag": tag,
                        "date": TARGET_DATE,
                        "match_id": match_id,
                        "won": won,
                        "rr_change": rr_change,
                        "rr_after": rr_after,
                        "tier": tier,
                        "kills": kills,
                        "deaths": deaths,
                        "assists": assists,
                        "agent": agent,
                        "map": map_name,
                    }
                )
                inserted += 1

            print(f"  Inserted {inserted} game(s) for {name}#{tag}")
            inserted_total += inserted

            # Get live MMR for current RR (end of day) and recalculate rr_after/rr_change
            live_mmr = await fetch_live_mmr(session, name, tag, region)
            live_rr = live_mmr.get("current", {}).get("rr", 0)
            live_tier = live_mmr.get("current", {}).get("tier", {}).get("name", "")

            all_player_games = (
                await db["val_games"]
                .find({"puuid": puuid, "date": TARGET_DATE})
                .sort("_id", 1)
                .to_list(length=100)
            )

            if all_player_games and live_rr:
                # Work backwards from current RR using rr_change from history where available
                # Set last game's rr_after to live current RR
                last_game = all_player_games[-1]
                await db["val_games"].update_one(
                    {"_id": last_game["_id"]},
                    {
                        "$set": {
                            "rr_after": live_rr,
                            "tier": live_tier or last_game.get("tier", ""),
                        }
                    },
                )
                # Recalculate rr_after for earlier games using history rr_change
                running_rr = live_rr
                for game in reversed(all_player_games):
                    rr_chg = rr_map.get(game.get("match_id", ""), 0)
                    if rr_chg:
                        prev_rr = running_rr - rr_chg
                        await db["val_games"].update_one(
                            {"_id": game["_id"]},
                            {"$set": {"rr_after": running_rr, "rr_change": rr_chg}},
                        )
                        running_rr = prev_rr

            await asyncio.sleep(1)

    print(f"\nTotal inserted: {inserted_total}")

    # 3. Post daily summary via Discord bot
    print("\nPosting daily summary...")
    settings = await db["guild_settings"].find_one({"guild_id": GUILD_ID})
    if not settings:
        settings = await db["settings"].find_one({"guild_id": GUILD_ID})

    if not settings or not settings.get("rr_channel_id"):
        print("No RR channel configured - skipping summary post")
        client.close()
        return

    channel_id = settings["rr_channel_id"]

    # Build summary
    games = (
        await db["val_games"]
        .find({"guild_id": GUILD_ID, "date": TARGET_DATE})
        .to_list(length=500)
    )

    if not games:
        print("No games found for summary")
        client.close()
        return

    by_player: dict[str, list] = {}
    for g in games:
        key = g.get("puuid") or g.get("val_name", "?")
        by_player.setdefault(key, []).append(g)

    lines = []
    for _, player_games in sorted(
        by_player.items(),
        key=lambda kv: sum(g["rr_change"] for g in kv[1]),
        reverse=True,
    ):
        total_rr = sum(g["rr_change"] for g in player_games)
        wins = sum(1 for g in player_games if g["won"])
        losses = len(player_games) - wins
        win_rate = round(wins / len(player_games) * 100)
        end_rr = player_games[-1]["rr_after"]
        start_rr = end_rr - total_rr
        tier = player_games[-1]["tier"]
        name = player_games[0]["val_name"]
        tag = player_games[0]["val_tag"]
        rr_str = f"+{total_rr}" if total_rr >= 0 else str(total_rr)
        lines.append(
            f"**{name}#{tag}** : {rr_str}\n"
            f"{wins}W {losses}L ({win_rate}%) | {tier} {start_rr}rr → {tier} {end_rr}rr"
        )

    # Post via Discord
    intents = discord.Intents.default()
    dc = discord.Client(intents=intents)

    @dc.event
    async def on_ready():
        channel = dc.get_channel(channel_id)
        if not channel:
            channel = await dc.fetch_channel(channel_id)
        embed = discord.Embed(
            title="📊 Yesterday's Summary (corrected)",
            description="\n\n".join(lines),
            color=COLOUR_LB,
        )
        embed.set_footer(text=f"{TARGET_DATE}  •  Reverie  •  corrected")
        await channel.send(embed=embed)
        print("Summary posted!")
        await dc.close()

    await dc.start(BOT_TOKEN)
    client.close()


if __name__ == "__main__":
    asyncio.run(rebuild())
