"""
Test script: simulates the poll cycle by fetching MMR history for all tracked
accounts rapidly, then immediately fetches history again for all accounts
(simulating the match-scan history fallback). Logs status codes to check
for rate limiting.

Run with:
    python scripts/test_rate_limit.py
"""

import asyncio
import os
from urllib.parse import quote
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
import aiohttp

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "discord_points")
HENRIK_API_KEY = os.getenv("HENRIK_API_KEY", "")
GUILD_ID = int(os.getenv("GUILD_ID", "0"))
API_BASE = "https://api.henrikdev.xyz"


async def fetch_history(session, name, tag, region, label=""):
    url = f"{API_BASE}/valorant/v1/mmr-history/{region}/{quote(name)}/{quote(tag)}"
    async with session.get(url, headers={"Authorization": HENRIK_API_KEY}) as resp:
        data = await resp.json() if resp.status == 200 else {}
        top_match = (
            data.get("data", [{}])[0].get("match_id", "none")[:8]
            if data.get("data")
            else "none"
        )
        print(f"  [{label}] {name}#{tag} -> {resp.status} | top match: {top_match}")
        return resp.status


async def main():
    client = AsyncIOMotorClient(MONGO_URI)
    db = client[DB_NAME]
    accounts = await db["riot_accounts"].find({"guild_id": GUILD_ID}).to_list(100)
    print(f"Found {len(accounts)} accounts\n")

    async with aiohttp.ClientSession() as session:
        # Phase 1: simulate poll (1s stagger like the real poll)
        print("Phase 1: Poll cycle (1s stagger)")
        for acc in accounts:
            await fetch_history(
                session,
                acc["val_name"],
                acc["val_tag"],
                acc.get("val_region", "eu"),
                "poll",
            )
            await asyncio.sleep(1)

        # Phase 2: simulate match-scan history fetch (30s later, no stagger)
        print(f"\nWaiting 30s to simulate match-scan delay...")
        await asyncio.sleep(30)
        print("Phase 2: Match-scan history fetch (rapid)")
        for acc in accounts:
            await fetch_history(
                session,
                acc["val_name"],
                acc["val_tag"],
                acc.get("val_region", "eu"),
                "match-scan",
            )
            await asyncio.sleep(0.5)

    client.close()
    print("\nDone!")


if __name__ == "__main__":
    asyncio.run(main())
